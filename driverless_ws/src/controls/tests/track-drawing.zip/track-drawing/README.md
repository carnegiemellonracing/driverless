To use:
check versions of python and pip

Install pygame (if not already):
pip install pygame

run the following command:
python visualize_track.py

instructions:
	to add a right cone - right click
	to add a left cone - left click

	pan using arrow keys

	to save point data in a file, press 's'

	chunk instructions:
		press 'd' once and then drag to shape your chunk
		move mouse to desired location and then press 'd' again

		to save data only in chunk(s) - press 's' while chunk is active

		press 'c' to clear chunks

find the data in the data folder
name of files are based on datetime information